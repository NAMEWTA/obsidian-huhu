package anthropic

import (
	"encoding/json"
	"strings"

	"github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/adapters/outbound/eino/common"
	"github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/adapters/outbound/eino/httpcall"
	"github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/application/api"
	"github.com/cloudwego/eino/schema"
)

const maxBlocks = 2048

type contentBlock struct {
	fields map[string]json.RawMessage
	text   string
	done   bool
}

type streamState struct {
	messageID, reason, emitted     string
	started, messageDelta, stopped bool
	blocks                         []*contentBlock
	emit                           func(string) error
	usage                          usageState
	observation                    api.AttemptObservation
	wireError                      error
}

func newStreamState(emit func(string) error) *streamState {
	return &streamState{emit: emit, observation: api.AttemptObservation{Knowledge: "unknown"}}
}

func (s *streamState) observe(event httpcall.SSEEvent) (err error) {
	defer func() {
		if err != nil {
			s.wireError = err
		}
	}()
	invalid := func() error { return common.Fault("MODEL_STREAM_INVALID") }
	object, err := readObject(event.Data, common.MaxEventBytes)
	if err != nil {
		return err
	}
	kind, ok := stringField(object, "type")
	if !ok || event.Event != kind {
		return invalid()
	}
	if kind == "ping" {
		if !onlyKeys(object, "type") {
			return invalid()
		}
		return nil
	}
	if s.stopped {
		return invalid()
	}
	if kind == "message_start" {
		if s.started || !onlyKeys(object, "type", "message") {
			return invalid()
		}
		message, err := readObject(object["message"], common.MaxEventBytes)
		if err != nil || !onlyKeys(message, "id", "type", "role", "model", "content", "stop_reason", "stop_sequence", "usage", "container", "stop_details") {
			return invalid()
		}
		id, idOK := stringField(message, "id")
		model, modelOK := stringField(message, "model")
		typeName, typeOK := stringField(message, "type")
		role, roleOK := stringField(message, "role")
		var content []json.RawMessage
		if !idOK || id == "" || !modelOK || model == "" || !typeOK || typeName != "message" || !roleOK || role != "assistant" || string(message["content"]) == "null" || json.Unmarshal(message["content"], &content) != nil || len(content) != 0 || string(message["stop_reason"]) != "null" || !absentOrNull(message, "stop_sequence") || !absentOrNull(message, "container") || !absentOrNull(message, "stop_details") {
			return invalid()
		}
		s.started, s.messageID = true, id
		s.usage.update(message["usage"], false)
		return nil
	}
	if !s.started {
		return invalid()
	}
	switch kind {
	case "message_delta":
		if !onlyKeys(object, "type", "delta", "usage") || !s.allBlocksStopped() {
			return invalid()
		}
		delta, err := readObject(object["delta"], common.MaxEventBytes)
		if err != nil || !onlyKeys(delta, "stop_reason", "stop_sequence", "container", "stop_details") || !absentOrNull(delta, "container") || !absentOrNull(delta, "stop_details") {
			return invalid()
		}
		if !absentOrNull(delta, "stop_reason") {
			reason, ok := stringField(delta, "stop_reason")
			if !ok || reason == "" || (s.reason != "" && s.reason != reason) {
				return invalid()
			}
			s.reason = reason
		}
		if !absentOrNull(delta, "stop_sequence") {
			if _, ok := stringField(delta, "stop_sequence"); !ok || s.reason != "stop_sequence" {
				return invalid()
			}
		}
		s.messageDelta = true
		s.usage.update(object["usage"], true)
		return nil
	case "message_stop":
		if !onlyKeys(object, "type") || !s.messageDelta || s.reason == "" || !s.allBlocksStopped() {
			return invalid()
		}
		s.stopped = true
		s.observation = s.usage.observation()
		return nil
	}
	if s.messageDelta {
		return invalid()
	}
	index, ok := indexField(object, "index")
	if !ok {
		return invalid()
	}
	if kind == "content_block_start" {
		if !onlyKeys(object, "type", "index", "content_block") || index != len(s.blocks) || index >= maxBlocks {
			return invalid()
		}
		fields, err := validateTextBlock(object["content_block"])
		if err != nil {
			return err
		}
		text, _ := stringField(fields, "text")
		s.blocks = append(s.blocks, &contentBlock{fields: fields, text: text})
		return s.flushText()
	}
	if index >= len(s.blocks) || s.blocks[index].done {
		return invalid()
	}
	block := s.blocks[index]
	switch kind {
	case "content_block_delta":
		if !onlyKeys(object, "type", "index", "delta") {
			return invalid()
		}
		delta, err := readObject(object["delta"], common.MaxEventBytes)
		if err != nil || !onlyKeys(delta, "type", "text") {
			return invalid()
		}
		kind, kindOK := stringField(delta, "type")
		text, textOK := stringField(delta, "text")
		if !kindOK || kind != "text_delta" || !textOK {
			return invalid()
		}
		if len(block.text)+len(text) > common.MaxTextBytes {
			return common.Fault("MODEL_TEXT_LIMIT")
		}
		block.text += text
		return s.flushText()
	case "content_block_stop":
		if !onlyKeys(object, "type", "index") {
			return invalid()
		}
		block.done = true
		block.fields["text"], _ = json.Marshal(block.text)
		return s.flushText()
	default:
		return invalid()
	}
}

func validateTextBlock(raw []byte) (map[string]json.RawMessage, error) {
	object, err := readObject(raw, common.MaxResponseBytes)
	kind, kindOK := stringField(object, "type")
	text, textOK := stringField(object, "text")
	if err != nil || !onlyKeys(object, "type", "text", "citations") || !kindOK || kind != "text" || !textOK || len(text) > common.MaxTextBytes {
		return nil, common.Fault("MODEL_STREAM_INVALID")
	}
	if value, ok := object["citations"]; ok && string(value) != "null" {
		var citations []json.RawMessage
		if json.Unmarshal(value, &citations) != nil || len(citations) != 0 {
			return nil, common.Fault("MODEL_STREAM_INVALID")
		}
	}
	return object, nil
}

func (s *streamState) allBlocksStopped() bool {
	for _, block := range s.blocks {
		if !block.done {
			return false
		}
	}
	return true
}

func (s *streamState) flushText() error {
	var text strings.Builder
	for _, block := range s.blocks {
		text.WriteString(block.text)
		if text.Len() > common.MaxTextBytes {
			return common.Fault("MODEL_TEXT_LIMIT")
		}
		if !block.done {
			break
		}
	}
	current := text.String()
	if !strings.HasPrefix(current, s.emitted) {
		return common.Fault("MODEL_STREAM_INVALID")
	}
	if len(current) > len(s.emitted) && s.emit != nil {
		if err := s.emit(current[len(s.emitted):]); err != nil {
			return err
		}
	}
	s.emitted = current
	return nil
}

func (s *streamState) finish() (*schema.Message, savedRound, error) {
	round := savedRound{MessageID: s.messageID, StopReason: s.reason}
	if !s.started || !s.stopped || !s.allBlocksStopped() {
		return nil, round, common.Fault("MODEL_STREAM_INCOMPLETE")
	}
	switch s.reason {
	case "end_turn":
	case "max_tokens":
		return nil, round, common.Fault("MODEL_OUTPUT_TRUNCATED")
	case "refusal":
		return nil, round, common.Fault("MODEL_REFUSED")
	default:
		return nil, round, common.Fault("MODEL_FINISH_UNKNOWN")
	}
	for index, block := range s.blocks {
		raw, err := json.Marshal(block.fields)
		if err != nil {
			return nil, round, common.Fault("MODEL_STREAM_INVALID")
		}
		round.Blocks = append(round.Blocks, savedBlock{Index: index, Raw: string(raw)})
	}
	message, err := projectBlocks(round.Blocks)
	if err != nil || message.Content != s.emitted {
		return nil, round, common.Fault("MODEL_STREAM_INVALID")
	}
	return message, round, nil
}

func projectBlocks(blocks []savedBlock) (*schema.Message, error) {
	if len(blocks) > maxBlocks {
		return nil, common.Fault("MODEL_STREAM_INVALID")
	}
	var text strings.Builder
	for i, block := range blocks {
		if block.Index != i {
			return nil, common.Fault("MODEL_STREAM_INVALID")
		}
		fields, err := validateTextBlock([]byte(block.Raw))
		if err != nil {
			return nil, err
		}
		value, _ := stringField(fields, "text")
		text.WriteString(value)
		if text.Len() > common.MaxTextBytes {
			return nil, common.Fault("MODEL_TEXT_LIMIT")
		}
	}
	return schema.AssistantMessage(text.String(), nil), nil
}
