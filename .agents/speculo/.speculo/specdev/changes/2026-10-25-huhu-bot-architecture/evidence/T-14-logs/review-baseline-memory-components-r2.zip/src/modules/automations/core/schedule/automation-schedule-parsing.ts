// Adapted from stablyai/orca 27b823f934f739bc85914dd717b776835f60bcf7 (MIT), Copyright (c) 2026 Lovecast Inc.: src/shared/automation-schedule-parsing.ts

import {
	DAY_NAMES,
	MONTH_NAMES,
	isCronDayFieldRestricted,
	parseCronField,
	type CronParseOptions,
} from './automation-cron-field-parsing';
import { cronHasPossibleOccurrence } from './automation-cron-occurrence';

const isClipboardTextByteLengthOverLimit = (text: string, max: number): boolean =>
	new TextEncoder().encode(text).length > max;

export const AUTOMATION_CRON_EXPRESSION_MAX_BYTES = 2 * 1024;
export type ParsedRrule = {
	kind: 'rrule';
	freq: 'HOURLY' | 'DAILY' | 'WEEKLY';
	byDay: string[];
	byHour: number;
	byMinute: number;
};

export type ParsedCron = {
	kind: 'cron';
	minutes: Set<number>;
	hours: Set<number>;
	daysOfMonth: Set<number>;
	months: Set<number>;
	daysOfWeek: Set<number>;
	dayOfMonthRestricted: boolean;
	dayOfWeekRestricted: boolean;
};

export type ParsedSchedule = ParsedRrule | ParsedCron;
export type { CronParseOptions };

const DAY_CODES = ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'] as const;

function parseRrule(rrule: string): ParsedRrule {
	const entries = new Map<string, string>();
	for (const part of rrule.replace(/^RRULE:/i, '').split(';')) {
		const [key, value] = part.split('=');
		if (
			!key ||
			!value ||
			!['FREQ', 'BYDAY', 'BYHOUR', 'BYMINUTE'].includes(key.toUpperCase()) ||
			entries.has(key.toUpperCase())
		)
			throw new Error('Unsupported recurrence field');
		if (key && value) {
			entries.set(key.toUpperCase(), value);
		}
	}
	const freq = entries.get('FREQ');
	if (freq !== 'HOURLY' && freq !== 'DAILY' && freq !== 'WEEKLY') {
		throw new Error('Unsupported automation recurrence.');
	}
	const byHour = Number(entries.get('BYHOUR') ?? '9');
	const byMinute = Number(entries.get('BYMINUTE') ?? '0');
	if (!Number.isInteger(byHour) || byHour < 0 || byHour > 23) {
		throw new Error('Invalid recurrence hour.');
	}
	if (!Number.isInteger(byMinute) || byMinute < 0 || byMinute > 59) {
		throw new Error('Invalid recurrence minute.');
	}
	const byDay = (entries.get('BYDAY') ?? '').split(',').filter(Boolean);
	if (freq !== 'WEEKLY' && byDay.length) throw new Error('BYDAY requires WEEKLY');
	if (
		freq === 'WEEKLY' &&
		(byDay.length === 0 || byDay.some((day) => !DAY_CODES.includes(day as (typeof DAY_CODES)[number])))
	) {
		throw new Error('Invalid recurrence day.');
	}
	return { kind: 'rrule', freq, byDay, byHour, byMinute };
}

export function parseCronExpression(expression: string, options: CronParseOptions = {}): ParsedCron {
	const parts = getAutomationCronExpressionFields(expression, 6);
	if (parts.length !== 5) {
		throw new Error('Cron schedule must have five fields.');
	}
	const [minute = '', hour = '', dayOfMonth = '', month = '', dayOfWeek = ''] = parts;
	const rejectOversizedStep = options.rejectOversizedStep ?? false;
	return {
		kind: 'cron',
		minutes: parseCronField({
			value: minute,
			min: 0,
			max: 59,
			field: 'minute',
			rejectOversizedStep,
		}),
		hours: parseCronField({ value: hour, min: 0, max: 23, field: 'hour', rejectOversizedStep }),
		daysOfMonth: parseCronField({
			value: dayOfMonth,
			min: 1,
			max: 31,
			field: 'day of month',
			rejectOversizedStep,
		}),
		months: parseCronField({
			value: month,
			min: 1,
			max: 12,
			field: 'month',
			names: MONTH_NAMES,
			rejectOversizedStep,
		}),
		daysOfWeek: parseCronField({
			value: dayOfWeek,
			min: 0,
			max: 7,
			field: 'day of week',
			names: DAY_NAMES,
			normalize: (value) => (value === 7 ? 0 : value),
			distinctValueCount: 7,
			rejectOversizedStep,
		}),
		dayOfMonthRestricted: isCronDayFieldRestricted(dayOfMonth),
		dayOfWeekRestricted: isCronDayFieldRestricted(dayOfWeek),
	};
}

export function getAutomationCronExpressionFields(expression: string, maxFields = 5): string[] {
	if (isClipboardTextByteLengthOverLimit(expression, AUTOMATION_CRON_EXPRESSION_MAX_BYTES)) {
		return [];
	}
	const fields: string[] = [];
	let tokenStart = -1;
	for (let index = 0; index <= expression.length; index += 1) {
		const isEnd = index === expression.length;
		if (!isEnd && !isAutomationCronFieldWhitespace(expression.charCodeAt(index))) {
			if (tokenStart === -1) {
				tokenStart = index;
			}
			continue;
		}
		if (tokenStart !== -1) {
			fields.push(expression.slice(tokenStart, index));
			tokenStart = -1;
			if (fields.length >= maxFields) {
				break;
			}
		}
	}
	return fields;
}

function isAutomationCronFieldWhitespace(code: number): boolean {
	return (
		code === 32 ||
		(code >= 9 && code <= 13) ||
		code === 160 ||
		code === 5760 ||
		(code >= 8192 && code <= 8202) ||
		code === 8232 ||
		code === 8233 ||
		code === 8239 ||
		code === 8287 ||
		code === 12288 ||
		code === 65279
	);
}

export function parseSchedule(schedule: string, options: CronParseOptions = {}): ParsedSchedule {
	const trimmed = schedule.trim();
	if (trimmed.includes('=')) {
		return parseRrule(trimmed);
	}
	return parseCronExpression(trimmed, options);
}

function scheduleRuns(schedule: string, options: CronParseOptions): boolean {
	try {
		const parsed = parseSchedule(schedule, options);
		return parsed.kind !== 'cron' || cronHasPossibleOccurrence(parsed, Date.now());
	} catch {
		return false;
	}
}

/** Accepts a schedule as new input, oversized-step refusal included (#15895). */
export function isValidAutomationSchedule(schedule: string): boolean {
	return scheduleRuns(schedule, { rejectOversizedStep: true });
}
