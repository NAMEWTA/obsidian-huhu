package execution

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"reflect"

	conv "github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/adapters/outbound/sqlite/conversation"
	"github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/application/api"
	executorapp "github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/application/execution/executor"
)

type RecoveryGuard interface {
	CheckInTx(context.Context, *sql.Tx, string) error
	ResetRuntimeInTx(context.Context, *sql.Tx) error
	MarkInterruptedTreesInTx(context.Context, *sql.Tx, []string) error
}

func (s *Store) StopAdmission()              { s.stopping.Store(true) }
func (s *Store) SetRecovery(g RecoveryGuard) { s.recovery = g }

// ReadRecoveryInTx shares the original owner, Session, configuration-pin and
// effective-provenance readers. It neither consumes a continuation nor claims.
func (s *Store) ReadRecoveryInTx(ctx context.Context, tx *sql.Tx, id api.RequestIdentity, q api.IDQuery) (api.RecoveryInspection, error) {
	var out api.RecoveryInspection
	var e error
	out.Run, out.Access, e = ReadInTx(ctx, tx, id, q)
	if e != nil {
		return out, e
	}
	out.Config, _, e = s.ReadExecutionConfigInTx(ctx, tx, q.ID)
	if e != nil {
		return out, e
	}
	var raw string
	if e = tx.QueryRowContext(ctx, "SELECT intent,execution_position_json FROM execution_runs WHERE run_id=?", q.ID).Scan(&out.Intent, &raw); e != nil {
		return out, e
	}
	if raw != "" {
		if json.Unmarshal([]byte(raw), &out.Position) != nil {
			return out, conv.Fault("CONFLICT", "RECOVERY_POSITION_INVALID")
		}
		// Continue and the program-position write are distinct commits. If
		// Continue committed but the following position write failed, derive
		// its already-completed decision from the original effect facts. No
		// continuation is reset, consumed twice or dispatched again.
		if out.Position.Phase == "continuation" && out.Position.Continuation != nil && out.Position.Continuation.Kind == "" {
			if legacy, ok := s.control.(interface {
				LegacyPositionInTx(context.Context, *sql.Tx, string) (api.ExecutionPosition, error)
			}); ok {
				actual, e := legacy.LegacyPositionInTx(ctx, tx, q.ID)
				if e != nil {
					return out, e
				}
				if actual.Phase == "resume" {
					if !reflect.DeepEqual(actual.Continuation, out.Position.Continuation) {
						return out, conv.Fault("CONFLICT", "RECOVERY_POSITION_INVALID")
					}
					out.Position = actual
				}
			}
		}
		return out, nil
	}
	if legacy, ok := s.control.(interface {
		LegacyPositionInTx(context.Context, *sql.Tx, string) (api.ExecutionPosition, error)
	}); ok {
		out.Position, e = legacy.LegacyPositionInTx(ctx, tx, q.ID)
		if e != nil {
			return out, e
		}
	}
	if out.Position.Phase == "" {
		if legacy, ok := s.tree.(interface {
			LegacyPositionInTx(context.Context, *sql.Tx, string) (api.ExecutionPosition, error)
		}); ok {
			out.Position, e = legacy.LegacyPositionInTx(ctx, tx, q.ID)
			if e != nil {
				return out, e
			}
		}
	}
	if out.Position.Phase == "" {
		out.Position.Phase = "run"
	}
	return out, nil
}

// ResumeInTx only reopens the selected program position. It preserves all
// original ledgers and identities; the next Claim allocates a fresh token.
func (s *Store) ResumeInTx(ctx context.Context, tx *sql.Tx, id api.RequestIdentity, profileID, runID string) error {
	inspected, e := s.ReadRecoveryInTx(ctx, tx, id, api.IDQuery{ProfileID: profileID, ID: runID})
	if e != nil {
		return e
	}
	switch inspected.Run.Status {
	case "interrupted", "blocked":
	default:
		return conv.Fault("CONFLICT", "RUN_NOT_INTERRUPTED")
	}
	raw, e := json.Marshal(inspected.Position)
	if e != nil {
		return e
	}
	result, e := tx.ExecContext(ctx, "UPDATE execution_runs SET status='recovering',revision=revision+1,reason='',claim_token='',execution_position_json=? WHERE run_id=? AND revision=? AND status IN('interrupted','blocked')", string(raw), runID, inspected.Run.Revision)
	if e != nil {
		return e
	}
	n, e := result.RowsAffected()
	if e != nil {
		return e
	}
	if n != 1 {
		return conv.Fault("CONFLICT", "REVISION_CONFLICT")
	}
	return AddEventInTx(ctx, tx, runID, "recovering", map[string]string{"status": "recovering"})
}
func (s *Store) SaveResume(ctx context.Context, w executorapp.Work, decision api.ToolResult) error {
	if w.Continuation == nil {
		return api.Invalid("RECOVERY_POSITION_INVALID")
	}
	return s.Base.WithinTx(ctx, func(tx *sql.Tx) error {
		if s.recovery != nil {
			if e := s.recovery.CheckInTx(ctx, tx, w.Run.ID); e != nil {
				return e
			}
		}
		p := api.ExecutionPosition{Phase: "resume", Continuation: w.Continuation, Decision: &decision}
		result, e := tx.ExecContext(ctx, "UPDATE execution_runs SET execution_position_json=? WHERE run_id=? AND claim_token=? AND status='running'", jsonArray(p), w.Run.ID, w.ClaimToken)
		if e != nil {
			return e
		}
		n, e := result.RowsAffected()
		if e != nil {
			return e
		}
		if n != 1 {
			return conv.Fault("CONFLICT", "RUN_CLAIM_CHANGED")
		}
		return nil
	})
}
func recoveryRefusal(e error) bool {
	var f *api.Fault
	return errors.As(e, &f) && f.Kind == "CAPABILITY_DENIED" && (f.Reason == "RECOVERY_REQUIRED" || f.Reason == "SERVICE_STOPPING")
}
