package usage

import (
	"context"
	"database/sql"
	"encoding/json"

	"github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/adapters/outbound/sqlite/execution"
	access "github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/application/access/context"
	"github.com/NAMEWTA/obsidian-huhu/native/huhubot/internal/application/api"
)

// MessagesInTx is consumed by the original Executor after claim. Only this
// execution's durable inbox is selected; Agent ID alone is never a namespace.
func (s *Store) MessagesInTx(ctx context.Context, tx *sql.Tx, runID string) ([]api.AgentMessage, error) {
	var principal, profile string
	if e := tx.QueryRowContext(ctx, "SELECT r.principal_id,s.profile_id FROM execution_runs r JOIN conversation_sessions s ON s.session_id=r.session_id WHERE r.run_id=?", runID).Scan(&principal, &profile); e != nil {
		return nil, e
	}
	id := api.NewConnectionIdentity("executor:"+runID, principal, false)
	_, in, e := execution.ReadInTx(ctx, tx, id, api.IDQuery{ProfileID: profile, ID: runID})
	if e != nil {
		return nil, e
	}
	rows, e := tx.QueryContext(ctx, "SELECT message_id,from_agent_id,to_agent_id,text,created_at,kind,status,delegation_id,question_id,work_thread_id,source_json FROM collaboration_messages WHERE to_run_id=? AND principal_id=? ORDER BY created_at,message_id LIMIT 101", runID, principal)
	if e != nil {
		return nil, e
	}
	type item struct {
		message api.AgentMessage
		sources []api.SourceSnapshot
	}
	all := []item{}
	for rows.Next() {
		var v item
		var raw string
		m := &v.message
		if e = rows.Scan(&m.ID, &m.FromAgentID, &m.ToAgentID, &m.Text, &m.CreatedAt, &m.Kind, &m.Status, &m.DelegationID, &m.QuestionID, &m.WorkThreadID, &raw); e != nil {
			rows.Close()
			return nil, e
		}
		if json.Unmarshal([]byte(raw), &v.sources) != nil {
			rows.Close()
			return nil, fail("CONFLICT", "MESSAGE_CONTEXT_INVALID")
		}
		all = append(all, v)
	}
	e = rows.Err()
	rows.Close()
	if e != nil {
		return nil, e
	}
	if len(all) > 100 {
		return nil, fail("RESOURCE_LIMIT", "THREAD_MESSAGE_LIMIT")
	}
	out := []api.AgentMessage{}
	total := 0
	for _, v := range all {
		if in.Group != nil && v.message.Text != "" {
			origin, derived, e := s.access.PrivateMessageInTx(ctx, tx, id, profile, v.message.ID)
			if e != nil {
				return nil, e
			}
			if e = s.access.ConsumePrivateInTx(ctx, tx, id, in, origin, derived); e != nil {
				return nil, e
			}
			_, in, e = execution.ReadInTx(ctx, tx, id, api.IDQuery{ProfileID: profile, ID: runID})
			if e != nil {
				return nil, e
			}
		}
		check := access.HistoryReadInput(in, v.sources)
		if in.ParentScope != nil && !access.InParent(check) {
			return nil, api.Denied("PARENT_SCOPE_EXCEEDED")
		}
		if e = s.access.CheckInTx(ctx, tx, id, check, []string{"read", "send"}); e != nil {
			return nil, e
		}
		total += len(v.message.Text)
		if total > 256*1024 {
			return nil, fail("RESOURCE_LIMIT", "THREAD_CONTEXT_LIMIT")
		}
		out = append(out, v.message)
	}
	return out, nil
}
