import { AGENT_CATALOG } from './catalog';
import type { AgentId, AgentSettings, PermissionMode } from './types';

const YOLO_FLAGS: Record<AgentId, readonly string[]> = Object.fromEntries(
	AGENT_CATALOG.map((agent) => [agent.id, agent.yoloFlags]),
) as Record<AgentId, readonly string[]>;

export function effectivePermission(settings: AgentSettings, agentId: AgentId): PermissionMode {
	const override = settings.agents[agentId]?.permissionMode ?? 'inherit';
	if (override === 'yolo' || override === 'manual') {
		return override;
	}
	return settings.globalPermissionMode;
}

export function launchArgs(settings: AgentSettings, agentId: AgentId): string[] {
	const override = settings.agents[agentId]?.argsOverride;
	if (override !== undefined) return splitArgs(override);
	const extra = (settings.agents[agentId]?.extraArgs ?? '').trim();
	if (extra.length > 0) {
		return splitArgs(extra);
	}
	if (effectivePermission(settings, agentId) === 'yolo') {
		return [...YOLO_FLAGS[agentId]];
	}
	return [];
}

/** Check the actual arguments so a custom manual override ignores the global mode. */
export function needsYoloConfirmation(settings: AgentSettings, agentId: AgentId): boolean {
	if (settings.yoloAcknowledgedAgents?.includes(agentId)) return false;
	const args = launchArgs(settings, agentId),
		flags = YOLO_FLAGS[agentId];
	if (!flags.length) return false;
	const start = args.indexOf(flags[0]!);
	return start >= 0 && flags.every((flag, index) => args[start + index] === flag);
}

export function splitArgs(value: string): string[] {
	const args: string[] = [];
	const pattern = /"([^"]*)"|'([^']*)'|(\S+)/g;
	for (const match of value.matchAll(pattern)) {
		args.push(match[1] ?? match[2] ?? match[3] ?? '');
	}
	return args.filter((part) => part.length > 0);
}
